# ZX · Microbiología

Tablero del **programa de monitoreo ambiental microbiológico de superficies inertes**
para la línea de empaque plástico flexible (extrusión → impresión → corrugadora → corte).

Mismo sistema de diseño que [ZX - Calidad](https://gamabet26.github.io/ZX-Calidad/), en un repositorio aparte
y con su propio proyecto Supabase: **MicrobiologiaZX** (`bbknvvngnauophdevvgj`, eu-west-2).

Referencia normativa: **SQF Food Packaging Code Ed. 9, cláusula 2.4.8** y requisitos equivalentes de BRCGS.

---

## Puesta en marcha (3 pasos)

### 1. Crear la tabla en Supabase

Entra al proyecto **MicrobiologiaZX** → **SQL Editor** → **New query**, pega el **contenido** (no el nombre) de
[`sql/01_tabla_monitoreo_micro.sql`](sql/01_tabla_monitoreo_micro.sql) y ejecútalo.
Crea la tabla `monitoreo_micro` con sus índices y políticas de acceso.

### 2. Pegar la llave de conexión

Abre `index.html` y busca cerca del inicio del script:

```js
const SB_KEY='PEGA_AQUI_TU_ANON_KEY';
```

Ve a **Settings → API Keys** del proyecto MicrobiologiaZX y copia la **llave pública**
(aparece como `anon` / `publishable`). Pégala entre las comillas.

⚠️ No uses la llave `service_role` / `secret`: esa da acceso total y no debe ir en una página web.

`SB_URL` ya viene configurada con la URL de este proyecto.

### 3. Publicar

1. Crea el repositorio `ZX-Microbiologia` en GitHub.
2. Sube `index.html`, la carpeta `sql/`, `.nojekyll` y este README.
3. **Settings → Pages → Branch: `main` / `/ (root)` → Save**.
4. Queda en `https://<tu-usuario>.github.io/ZX-Microbiologia/`.

> Mientras no haya conexión, el tablero entra en **modo local**: sigue funcionando y guarda
> en el navegador, con el indicador del encabezado en rojo. En *Configuración* hay un botón
> para reintentar la conexión y otro para cargar datos de ejemplo y ver cómo se comporta.

---

## Qué hace

| Sección | Contenido |
|---|---|
| **Monitoreo Ambiental** | Tarjetas de muestras, conformidad, alertas, fuera de límite, desviaciones abiertas y puntos vencidos. Gráficas de tendencia mensual, desviaciones por punto y mapa de riesgo punto × microorganismo. Tabla de resultados y lista de desviaciones abiertas. |
| **Programa de Muestreo** | Qué punto toca muestrear según su frecuencia, cuál está por vencer y cuál ya venció, más la matriz punto × microorganismo. |
| **ZX - Calidad** | Acceso al tablero de equipos de medición. |
| **Configuración** | Clave de administrador (se pide para eliminar), límites vigentes y estado de la conexión. |

El **dictamen se calcula solo** —Conforme / En alerta / Fuera de límite— contra los límites
del catálogo, así que no depende de quién capture. Cuando un resultado sale fuera de límite,
la desviación se abre automáticamente y no desaparece del tablero hasta que se cierra.

El botón **Excel** exporta lo que esté filtrado en ese momento, en dos hojas: *Resultados* y *Programa*.

---

## Adaptar el programa a la planta

Todo lo configurable está en el bloque **CATÁLOGO** al inicio del script de `index.html`:

| Constante | Qué controla |
|---|---|
| `PUNTOS` | Puntos de muestreo, departamento, proceso, zona de riesgo y frecuencia en días |
| `MICROS` | Microorganismos, tipo (cuantitativo/cualitativo), unidad, límite y nivel de alerta |
| `MATRIZ` | Qué microorganismos aplican a cada punto |
| `TURNOS`, `METODOS` | Listas desplegables de captura |
| `META` | Meta de conformidad (95% por defecto) |

Valores precargados:

| Microorganismo | Alerta | Límite |
|---|---|---|
| Aerobios mesófilos | ≥ 5 UFC/cm² | 10 UFC/cm² |
| Coliformes totales | ≥ 0.5 UFC/cm² | 1 UFC/cm² |
| Mohos y levaduras | ≥ 5 UFC/cm² | 10 UFC/cm² |
| *E. coli* | — | Ausencia / 100 cm² |
| *Salmonella* spp. | — | Ausencia / 100 cm² |

> ⚠️ **Son una propuesta de arranque, no un criterio oficial.** Deben validarse contra el
> análisis de riesgo, el histórico de la planta y los requisitos de los clientes de cárnicos
> RTE antes de usarse para liberar o retener producto.

---

## Nota de seguridad

La llave `anon` es pública por diseño y las políticas de la tabla están abiertas, igual que
en ZX-Calidad: cualquiera con la URL del tablero puede capturar y editar. La clave de administrador que
pide el tablero antes de eliminar vive en el navegador y es una barrera de conveniencia, no
de seguridad. Si el registro microbiológico se va a usar como evidencia ante auditoría,
conviene pasar a usuarios con contraseña de Supabase (`auth.uid()` en las políticas) —
el cambio es acotado y se puede hacer después sin tocar los datos.
